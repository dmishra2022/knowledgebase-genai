import React,{createContext,useState,useEffect,useContext} from 'react';
import api from '../api';import {AuthContext} from './AuthContext';
export const NoteContext=createContext();
export function NoteProvider({children}){const [notes,setNotes]=useState([]);const [loading,setLoading]=useState(false);
  const {token}=useContext(AuthContext);
  useEffect(()=>{if(token)loadNotes();},[token]);
  const loadNotes=async()=>{setLoading(true);const res=await api.get('/notes');setNotes(res.data);setLoading(false);};
  return <NoteContext.Provider value={{notes,loading,loadNotes}}>{children}</NoteContext.Provider>;
}
