import React, { createContext, useState } from 'react';
import api, { setAuthToken } from '../api';
export const AuthContext = createContext();
export function AuthProvider({ children }) {
  const [token,setToken]=useState(localStorage.getItem('token'));
  const [role,setRole]=useState(localStorage.getItem('role'));
  const [loading,setLoading]=useState(false);
  const login=async(email,password)=>{setLoading(true);
    const res=await api.post('/auth/login',{email,password});const data=res.data;
    if(data.token){setToken(data.token);localStorage.setItem('token',data.token);setAuthToken(data.token);}
    setLoading(false);return data;
  };
  const register=async(email,password,role)=>{setLoading(true);
    const res=await api.post('/auth/register',{email,password,role});
    setLoading(false);return res.data;
  };
  const logout=()=>{setToken(null);localStorage.removeItem('token');setAuthToken(null);};
  return <AuthContext.Provider value={{token,role,loading,login,register,logout}}>{children}</AuthContext.Provider>;
}
