import React,{createContext,useState,useEffect,useContext} from 'react';
import api from '../api';import {AuthContext} from './AuthContext';
export const PlanContext=createContext();
export function PlanProvider({children}){const [plans,setPlans]=useState([]);const [loading,setLoading]=useState(false);
  const {token}=useContext(AuthContext);
  useEffect(()=>{if(token)loadPlans();},[token]);
  const loadPlans=async()=>{setLoading(true);const res=await api.get('/plans');setPlans(res.data);setLoading(false);};
  return <PlanContext.Provider value={{plans,loading,loadPlans}}>{children}</PlanContext.Provider>;
}
