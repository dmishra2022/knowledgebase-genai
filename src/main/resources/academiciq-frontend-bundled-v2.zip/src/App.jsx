import React from 'react';import{Routes,Route}from'react-router-dom';import Navbar from'./components/Navbar';import LandingPage from'./components/LandingPage';import Login from'./components/Login';import Register from'./components/Register';import ProtectedRoute from'./components/ProtectedRoute';
import StudentDashboard from'./components/StudentDashboard';import InstitutionNoteUpload from'./components/InstitutionNoteUpload';import InstitutionNoteList from'./components/InstitutionNoteList';
import InstitutionAnalytics from'./components/InstitutionAnalytics';import InstitutionAdvertise from'./components/InstitutionAdvertise';
export default function App(){return(
  <div className="min-h-screen flex flex-col"><Navbar/><main className="flex-grow container mx-auto p-4"><Routes>
    <Route path="/" element={<LandingPage/>}/>
    <Route path="/login" element={<Login/>}/>
    <Route path="/register" element={<Register/>}/>
    <Route path="/student" element={<ProtectedRoute><StudentDashboard/></ProtectedRoute>}/>
    <Route path="/institution/upload" element={<ProtectedRoute><InstitutionNoteUpload/></ProtectedRoute>}/>
    <Route path="/institution/notes" element={<ProtectedRoute><InstitutionNoteList/></ProtectedRoute>}/>
    <Route path="/institution/analytics" element={<ProtectedRoute><InstitutionAnalytics/></ProtectedRoute>}/>
    <Route path="/institution/advertise" element={<ProtectedRoute><InstitutionAdvertise/></ProtectedRoute>}/>
  </Routes></main></div>
);}