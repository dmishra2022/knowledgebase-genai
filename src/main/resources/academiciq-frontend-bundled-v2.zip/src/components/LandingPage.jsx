import React from 'react';import {Link} from 'react-router-dom';
export default function LandingPage(){return <div className="text-center py-20">
<h1 className="text-4xl font-bold mb-4">Welcome to AcademicIQ</h1>
<p className="mb-8">Generate summaries, create audiobooks, and chat with your documents.</p>
<Link to="/register" className="px-4 py-2 bg-blue-600 text-white rounded mr-4">Get Started</Link>
<Link to="/login" className="px-4 py-2 border border-blue-600 text-blue-600 rounded">Login</Link>
</div>;}
