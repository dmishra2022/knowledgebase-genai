import React from 'react';import{Link}from'react-router-dom';import Button from'./ui/Button';
export default function StudentDashboard(){return <div><h2 className="text-2xl font-bold mb-4">Student Dashboard</h2>
<Link to="/notes/upload"><Button className="bg-green-500 text-white">Upload Note</Button></Link>
<Link to="/notes"><Button className="ml-4 bg-blue-500 text-white">My Notes</Button></Link>
<Link to="/plans"><Button className="ml-4 bg-yellow-500 text-white">Plans</Button></Link>
<Link to="/chat"><Button className="ml-4 bg-purple-500 text-white">Chat</Button></Link>
</div>;}
