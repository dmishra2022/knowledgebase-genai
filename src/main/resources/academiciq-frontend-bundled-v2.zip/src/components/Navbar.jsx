import React,useContext from 'react';import {Link} from 'react-router-dom';import {AuthContext} from '../context/AuthContext';
export default function Navbar(){const{token,logout}=useContext(AuthContext);
return <nav className="bg-white shadow"><div className="container mx-auto p-4 flex justify-between items-center">
<Link to="/" className="text-xl font-bold">AcademicIQ</Link><div className="flex space-x-4">
{token?<button onClick={logout} className="hover:text-red-600">Logout</button>:<>
<Link to="/login" className="hover:text-blue-600">Login</Link>
<Link to="/register" className="hover:text-blue-600">Register</Link></>}
</div></div></nav>;
}
