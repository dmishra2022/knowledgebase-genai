import React,{useState}from 'react';import api from '../api';import Card from'./ui/Card';import Button from'./ui/Button';
export default function InstitutionAdvertise(){const[bannerUrl,setBannerUrl]=useState('');const[targetLink,setTargetLink]=useState('');
const handleSubmit=async e=>{e.preventDefault();await api.post('/institution/advertise',{bannerUrl,targetLink});setBannerUrl('');setTargetLink('');};
return <Card className="max-w-md mx-auto mb-8"><h2 className="text-2xl font-bold mb-4">Create Advertisement</h2>
<form onSubmit={handleSubmit} className="space-y-4"><input type="url" placeholder="Banner Image URL" className="w-full p-2 border rounded" value={bannerUrl} onChange={e=>setBannerUrl(e.target.value)} required/>
<input type="url" placeholder="Target Link" className="w-full p-2 border rounded" value={targetLink} onChange={e=>setTargetLink(e.target.value)} required/>
<Button type="submit" className="w-full bg-blue-600 text-white">Publish Ad</Button></form></Card>;
}
