import React from 'react';import ReactModal from 'react-modal';ReactModal.setAppElement('#root');
export default function Modal({isOpen,onRequestClose,children}) {
  return <ReactModal isOpen={isOpen} onRequestClose={onRequestClose}
    className="bg-white rounded-lg p-6 max-w-lg mx-auto mt-20 outline-none"
    overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">{children}</ReactModal>;
}
