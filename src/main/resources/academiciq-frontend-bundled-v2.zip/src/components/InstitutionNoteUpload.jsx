import React,{useState,useContext}from 'react';import api from '../api';import{AuthContext}from'../context/AuthContext';import Button from'./ui/Button';import Card from'./ui/Card';
export default function InstitutionNoteUpload(){const[title,setTitle]=useState('');const[file,setFile]=useState(null);const[price,setPrice]=useState('');const{token}=useContext(AuthContext);
const handleSubmit=async e=>{e.preventDefault();const form=new FormData();form.append('title',title);form.append('file',file);form.append('price',price);
await api.post('/institution/notes/upload',form,{headers:{'Content-Type':'multipart/form-data'}});setTitle('');setFile(null);setPrice('');};
return <Card className="max-w-lg mx-auto"><h2 className="text-2xl font-bold mb-4">Upload & Price Note</h2>
<form onSubmit={handleSubmit} className="space-y-4">
<input type="text" placeholder="Title" className="w-full p-2 border rounded" value={title} onChange={e=>setTitle(e.target.value)} required/>
<input type="file" accept=".pdf,.docx,.txt" onChange={e=>setFile(e.target.files[0])} required/>
<input type="number" placeholder="Price (₹)" className="w-full p-2 border rounded" value={price} onChange={e=>setPrice(e.target.value)} required/>
<Button type="submit" className="w-full bg-green-600 text-white">Upload & Publish</Button>
</form></Card>;}
