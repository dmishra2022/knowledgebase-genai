import React,{useEffect,useState}from 'react';import api from '../api';import Spinner from'./ui/Spinner';import{ResponsiveContainer,LineChart,Line,XAxis,YAxis,Tooltip}from 'recharts';
export default function InstitutionAnalytics(){const[data,setData]=useState(null);
useEffect(()=>{api.get('/institution/analytics').then(res=>setData(res.data));},[]);
if(!data) return <Spinner/>;
return <div className="mb-8"><h2 className="text-2xl font-bold mb-4">Earnings Over Time</h2>
<ResponsiveContainer width="100%" height={300}><LineChart data={data}><XAxis dataKey="date"/><YAxis/><Tooltip/>
<Line dataKey="revenue" stroke="#4A90E2"/></LineChart></ResponsiveContainer></div>;
}
