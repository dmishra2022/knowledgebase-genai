import React,{useEffect,useState}from 'react';import api from '../api';import Card from'./ui/Card';import Button from'./ui/Button';import Spinner from'./ui/Spinner';
export default function InstitutionNoteList(){const[notes,setNotes]=useState([]);const[loading,setLoading]=useState(true);
useEffect(()=>{api.get('/institution/notes').then(res=>setNotes(res.data)).finally(()=>setLoading(false));},[]);
const handleDelete=async id=>{await api.delete(`/institution/notes/${id}`);setNotes(notes.filter(n=>n.id!==id));};
if(loading) return <Spinner/>;
return <div><h2 className="text-2xl font-bold mb-4">Your Published Notes</h2>
<div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{notes.map(n=>(
<Card key={n.id}><h3 className="font-semibold">{n.title}</h3><p>Price: ₹{n.price}</p><p>Sales: {n.salesCount}</p>
<div className="mt-2"><Button onClick={()=>handleDelete(n.id)} className="bg-red-600 text-white">Delete</Button></div>
</Card>))}</div></div>;}
