import React,{useState,useContext} from 'react';import{useNavigate}from'react-router-dom';import{AuthContext}from'../context/AuthContext';import Button from'./ui/Button';
export default function Register(){const[email,setEmail]=useState('');const[password,setPassword]=useState('');
const[role,setRole]=useState('STUDENT');const{register}=useContext(AuthContext);const navigate=useNavigate();
const handleSubmit=async e=>{e.preventDefault();await register(email,password,role);navigate('/login');};
return <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4">
<h2 className="text-2xl font-bold">Register</h2>
<input type="email" placeholder="Email" className="w-full p-2 border rounded" value={email} onChange={e=>setEmail(e.target.value)} required/>
<input type="password" placeholder="Password" className="w-full p-2 border rounded" value={password} onChange={e=>setPassword(e.target.value)} required/>
<select className="w-full p-2 border rounded" value={role} onChange={e=>setRole(e.target.value)}>
<option value="STUDENT">Student</option><option value="INSTITUTION">Institution</option><option value="ADMIN">Admin</option>
</select><Button type="submit" className="w-full bg-blue-600 text-white">Register</Button>
</form>;
}
