package com.academiciq.entity;

public enum Role {
    STUDENT,
    INSTITUTION,
    ADMIN
}
