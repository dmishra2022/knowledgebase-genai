package com.academiciq.controller;

import com.academiciq.entity.Purchase;
import com.academiciq.service.PaymentService;
import com.academiciq.service.PurchaseService;
import com.razorpay.Order;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/purchases")
@RequiredArgsConstructor
public class PurchaseController {
    private final PurchaseService purchaseService;
    private final PaymentService paymentService;

    @PostMapping("/order/{planId}")
    public ResponseEntity<Order> createOrder(@PathVariable UUID planId) throws Exception {
        // Fetch plan price from service
        var plan = purchaseService.getPlan(planId);
        int amountPaise = plan.getPrice().multiply(java.math.BigDecimal.valueOf(100)).intValue();
        Order order = paymentService.createOrder(planId.toString(), amountPaise, "INR");
        return ResponseEntity.ok(order);
    }

    @PostMapping("/complete")
    public ResponseEntity<Purchase> completePurchase(@RequestParam UUID userId,
                                                     @RequestParam UUID planId,
                                                     @RequestParam String paymentId) {
        // TODO: verify payment via webhook or client-side signature
        Purchase purchase = purchaseService.purchasePlan(userId, planId);
        purchase.setPaymentId(paymentId);
        return ResponseEntity.ok(purchase);
    }

    @GetMapping
    public ResponseEntity<List<Purchase>> listPurchases(@RequestParam UUID userId) {
        return ResponseEntity.ok(purchaseService.getUserPurchases(userId));
    }
}
