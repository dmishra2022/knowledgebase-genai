package com.academiciq.controller;

import com.academiciq.service.ChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
public class ChatController {
    private final ChatService chatService;

    @PostMapping("/")
    public ResponseEntity<String> chat(@RequestParam String documentText, @RequestParam String question) {
        return ResponseEntity.ok(chatService.chatWithDocument(documentText, question));
    }
}
