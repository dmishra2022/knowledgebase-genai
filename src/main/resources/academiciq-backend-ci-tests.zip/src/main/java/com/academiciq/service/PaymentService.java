package com.academiciq.service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private RazorpayClient client;

    public PaymentService(@Value("${razorpay.key_id}") String keyId,
                          @Value("${razorpay.key_secret}") String keySecret) throws Exception {
        this.client = new RazorpayClient(keyId, keySecret);
    }

    public Order createOrder(String planId, int amountInPaise, String currency) throws Exception {
        JSONObject options = new JSONObject();
        options.put("amount", amountInPaise);
        options.put("currency", currency);
        options.put("receipt", "order_rcpt_" + planId);
        options.put("payment_capture", 1);
        return client.Orders.create(options);
    }
}
