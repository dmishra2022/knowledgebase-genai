package com.academiciq.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ChatService {
    private final ChromaClient chromaClient;
    private final OpenAIClient openAIClient;

    public String chatWithDocument(String noteId, String question) {
        // Retrieve relevant contexts from ChromaDB
        List<String> contexts = chromaClient.query(List.of(question));
        // Combine contexts and question
        String prompt = String.join("\n", contexts) + "\nQuestion: " + question;
        // Call OpenAI to generate answer
        return openAIClient.generateAnswer(prompt);
    }
}
