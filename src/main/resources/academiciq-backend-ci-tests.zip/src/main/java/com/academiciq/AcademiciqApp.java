package com.academiciq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademiciqApp {
    public static void main(String[] args) {
        SpringApplication.run(AcademiciqApp.class, args);
    }
}
