package com.academiciq.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @GetMapping("/student")
    @PreAuthorize("hasAuthority('STUDENT')")
    public String studentAccess() {
        return "Student dashboard access granted";
    }

    @GetMapping("/institution")
    @PreAuthorize("hasAuthority('INSTITUTION')")
    public String institutionAccess() {
        return "Institution dashboard access granted";
    }

    @GetMapping("/admin")
    @PreAuthorize("hasAuthority('ADMIN')")
    public String adminAccess() {
        return "Admin dashboard access granted";
    }
}
