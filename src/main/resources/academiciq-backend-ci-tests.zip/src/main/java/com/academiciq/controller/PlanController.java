package com.academiciq.controller;

import com.academiciq.entity.Plan;
import com.academiciq.service.PlanService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/plans")
@RequiredArgsConstructor
public class PlanController {
    private final PlanService planService;

    @GetMapping
    public ResponseEntity<List<Plan>> listPlans() {
        return ResponseEntity.ok(planService.getAllPlans());
    }

    @PostMapping
    public ResponseEntity<Plan> createPlan(@RequestBody Plan plan) {
        return ResponseEntity.ok(planService.createPlan(plan));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Plan> getPlan(@PathVariable UUID id) {
        Plan plan = planService.getPlan(id);
        return plan != null ? ResponseEntity.ok(plan) : ResponseEntity.notFound().build();
    }
}
