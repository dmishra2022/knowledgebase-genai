package com.academiciq.service;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.List;
import java.util.Map;

@Component
public class ChromaClient {
    private final RestTemplate rest = new RestTemplate();
    private final String chromaUrl = "http://localhost:8000"; // ChromaDB endpoint

    public String createCollection(String name) {
        // TODO: call ChromaDB REST API to create collection
        return name;
    }

    public void addEmbeddings(String collection, List<float[]> embeddings, List<String> metadatas) {
        // TODO: POST embeddings to ChromaDB
    }

    public List<String> query(Collection<String> params) {
        // TODO: retrieve nearest docs
        return List.of("Context from document.");
    }
}
