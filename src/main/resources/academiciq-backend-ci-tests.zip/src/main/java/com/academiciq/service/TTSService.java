package com.academiciq.service;

import marytts.LocalMaryInterface;
import marytts.MaryInterface;
import marytts.exceptions.MaryConfigurationException;
import org.springframework.stereotype.Service;

import javax.sound.sampled.AudioInputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class TTSService {

    private MaryInterface maryTTS;

    public TTSService() throws MaryConfigurationException {
        maryTTS = new LocalMaryInterface();
    }

    public String generateAudio(String text, String outputFilename) throws IOException {
        try (AudioInputStream audio = maryTTS.generateAudio(text);
             OutputStream out = Files.newOutputStream(Path.of(outputFilename))) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = audio.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
        return outputFilename;
    }
}
