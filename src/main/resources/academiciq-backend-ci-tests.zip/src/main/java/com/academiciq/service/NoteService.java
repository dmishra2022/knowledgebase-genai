package com.academiciq.service;

import com.academiciq.entity.Note;
import com.academiciq.entity.User;
import com.academiciq.repository.NoteRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class NoteService {
    private final ChromaClient chromaClient;

    private final FileStorageService fileStorageService;
    private final OpenAIClient openAIClient;
    private final NoteRepository noteRepository;

    @Transactional
    public Note uploadAndProcess(Note note, MultipartFile file) throws IOException {
        // Store file
        String path = fileStorageService.storeFile(file);
        note.setContentUrl(path);

        // TODO: parse PDF/TXT; for now use filename as text
        String text = "Content from " + file.getOriginalFilename();

        // Generate summary
        String summary = openAIClient.generateSummary(text);
        note.setSummary(summary);
        // Generate embeddings for chat
        float[] embedding = openAIClient.generateEmbedding(text);
        chromaClient.createCollection("notes");
        chromaClient.addEmbeddings("notes", List.of(embedding), List.of(saved.getId().toString()));


        // TODO: generate audiobook

        return noteRepository.save(note);
    }

    public List<Note> getUserNotes(UUID userId) {
        return noteRepository.findByUserId(userId);
    }

    @Cacheable(cacheNames = "noteSummary", key = "#noteId")
    public String getSummary(UUID noteId) {
        return noteRepository.findById(noteId).map(Note::getSummary).orElse(null);
    }
}
