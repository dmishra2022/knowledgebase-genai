package com.academiciq.service;

import com.academiciq.entity.Purchase;
import com.academiciq.repository.PurchaseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PurchaseService {
    private final PurchaseRepository purchaseRepository;

    public Purchase purchasePlan(UUID userId, UUID planId) {
        Purchase purchase = new Purchase();
        purchase.setUserId(userId);
        purchase.setPlanId(planId);
        return purchaseRepository.save(purchase);
    }

    public List<Purchase> getUserPurchases(UUID userId) {
        return purchaseRepository.findByUserId(userId);
    }
}
