package com.academiciq.controller;

import com.academiciq.entity.Note;
import com.academiciq.service.NoteService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/notes")
@RequiredArgsConstructor
public class NoteController {
    private final NoteService noteService;

    @PostMapping("/upload")
    public ResponseEntity<Note> uploadNote(@RequestParam("title") String title,
                                           @RequestParam("file") MultipartFile file,
                                           Authentication auth) throws IOException {
        // Create note entity
        Note note = new Note();
        note.setTitle(title);
        // Associate with user
        note.setUser(new com.academiciq.entity.User(){{
            setEmail(auth.getName());
        }});
        Note saved = noteService.uploadAndProcess(note, file);
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public ResponseEntity<List<Note>> listNotes(Authentication auth) {
        // For demo, userId is email string; in real implement mapping
        // Placeholder: return all notes
        return ResponseEntity.ok(noteService.getUserNotes(null));
    }

    @GetMapping("/{id}/summary")
    public ResponseEntity<String> getSummary(@PathVariable UUID id) {
        String summary = noteService.getSummary(id);
        return ResponseEntity.ok(summary);
    }
}
