package com.academiciq.service;

import com.theokanning.openai.OpenAiService;
import com.theokanning.openai.embedding.EmbeddingRequest;
import com.theokanning.openai.completion.chat.ChatCompletionRequest;
import com.theokanning.openai.completion.chat.ChatMessage;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OpenAIClient {
    private final OpenAiService openAi = new OpenAiService(System.getenv("OPENAI_API_KEY"));

    public String generateSummary(String text) {
        // Simplified summary via Chat API
        ChatMessage system = new ChatMessage("system", "Summarize the following text");
        ChatMessage user = new ChatMessage("user", text);
        ChatCompletionRequest req = ChatCompletionRequest.builder()
                .model("gpt-4o-mini")
                .messages(List.of(system, user))
                .build();
        return openAi.createChatCompletion(req).getChoices().get(0).getMessage().getContent();
    }

    public float[] generateEmbedding(String text) {
        EmbeddingRequest req = EmbeddingRequest.builder()
                .model("text-embedding-ada-002")
                .input(List.of(text))
                .build();
        List<List<Float>> data = openAi.createEmbeddings(req).getData().get(0).getEmbedding();
        return data.stream().mapToFloat(Float::floatValue).toArray();
    }

    public String generateAnswer(String prompt) {
        ChatMessage system = new ChatMessage("system", "You are a helpful assistant.");
        ChatMessage user = new ChatMessage("user", prompt);
        ChatCompletionRequest req = ChatCompletionRequest.builder()
                .model("gpt-4o-mini")
                .messages(List.of(system, user))
                .build();
        return openAi.createChatCompletion(req).getChoices().get(0).getMessage().getContent();
    }
}
