package com.academiciq.service;

import com.academiciq.entity.Note;
import com.academiciq.repository.NoteRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;

public class NoteServiceTest {

    @Test
    void testGetSummaryCacheable() {
        NoteRepository repo = Mockito.mock(NoteRepository.class);
        PDFParsingService pdfService = Mockito.mock(PDFParsingService.class);
        OpenAIClient aiClient = Mockito.mock(OpenAIClient.class);
        NoteService noteService = new NoteService(null, aiClient, repo);

        Note note = new Note();
        note.setId(UUID.randomUUID());
        note.setSummary("Test summary");
        Mockito.when(repo.findById(note.getId())).thenReturn(Optional.of(note));

        String summary1 = noteService.getSummary(note.getId());
        String summary2 = noteService.getSummary(note.getId());

        assertEquals("Test summary", summary1);
        assertEquals("Test summary", summary2);
        Mockito.verify(repo, Mockito.times(1)).findById(note.getId());
    }
}
