package com.academiciq.controller;

import com.academiciq.dto.AuthResponse;
import com.academiciq.dto.LoginRequest;
import com.academiciq.dto.RegisterRequest;
import com.academiciq.entity.Role;
import com.academiciq.service.AuthService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
public class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthService authService;

    @Test
    @DisplayName("Register endpoint returns JWT token")
    void testRegister() throws Exception {
        Mockito.when(authService.register(any(RegisterRequest.class)))
               .thenReturn(new AuthResponse("mock-token"));

        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{"email":"test@example.com","password":"pass","role":"STUDENT"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("mock-token"));
    }

    @Test
    @DisplayName("Login endpoint returns JWT token")
    void testLogin() throws Exception {
        Mockito.when(authService.login(any(LoginRequest.class)))
               .thenReturn(new AuthResponse("login-token"));

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{"email":"test@example.com","password":"pass"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("login-token"));
    }
}
